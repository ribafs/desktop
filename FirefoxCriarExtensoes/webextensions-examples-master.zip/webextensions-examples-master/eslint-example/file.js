// This special eslint comment will declare that the named
// function has been "exported" into the global scope.

/* exported getUsefulContents */
function getUsefulContents(callback) {
    callback('Hello World');
}
