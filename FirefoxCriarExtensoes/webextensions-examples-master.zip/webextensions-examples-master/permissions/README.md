# Permissions Example

## What it does

An example using the permissions API to grant and revoke an optional permission.

## What it shows

How to request a permission, catching error conditions from the request and querying the permissions API.
